﻿using System.Collections.Generic;
using UnityEngine;
using MLAgents;

public class RollerAgent : Agent
{
    private GameObject wall;
    private int rando;
    private bool floor;
    private int score;
    Rigidbody rBody;
    void Start()
    {
        wall = GameObject.Find("Wall");
        rBody = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (wall.transform.position.x > 6 || wall.transform.position.x < -6 || wall.transform.position.z > 6 || wall.transform.position.z < -6)
        {
            
            rando = Random.Range(0, 4);
            switch (rando)
            {
                case 0:
                    wall.transform.position = new Vector3(0, 0.5f, -5.5f);
                    wall.transform.eulerAngles = new Vector3(wall.transform.eulerAngles.x,0,wall.transform.eulerAngles.z);
                    WallMovement.wallspeed = Random.Range(4f, 12f);
                    break;
                case 1:
                    wall.transform.position = new Vector3(-5.5f, 0.5f, 0);
                    wall.transform.eulerAngles = new Vector3(wall.transform.eulerAngles.x, 90, wall.transform.eulerAngles.z);
                    WallMovement.wallspeed = Random.Range(4f, 12f);
                    break;
                case 2:
                    wall.transform.position = new Vector3(0, 0.5f, 5.5f);
                    wall.transform.eulerAngles = new Vector3(wall.transform.eulerAngles.x, 180, wall.transform.eulerAngles.z);
                    WallMovement.wallspeed = Random.Range(4f, 12f);
                    break;
                case 3:
                    wall.transform.position = new Vector3(5.5f, 0.5f, 0);
                    wall.transform.eulerAngles = new Vector3(wall.transform.eulerAngles.x, 270, wall.transform.eulerAngles.z);
                    WallMovement.wallspeed = Random.Range(4f, 12f);
                    break;
            }
        }
        
    }

    public Transform Target;
    public override void AgentReset()
    {
        if (transform.position.x > 5 || transform.position.x < -5 || transform.position.z > 5 || transform.position.z < -5)
            {
            // If the Agent fell, zero its momentum
            this.rBody.angularVelocity = Vector3.zero;
            this.rBody.velocity = Vector3.zero;
            this.transform.position = new Vector3(0, 0.5f, 0);
        }

        // Move the target to a new spot
        /*
        Target.position = new Vector3(Random.value * 8 - 4,
                                      0.5f,
                                      Random.value * 8 - 4);*/
    }


    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "floor")
        {
            floor = true;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "floor")
        {
            floor = false;
        }

    }

    public override void CollectObservations()
    {
        // Target and Agent positions
        AddVectorObs(Target.position);
        AddVectorObs(this.transform.position);

        // Agent velocity
        AddVectorObs(rBody.velocity.x);
        AddVectorObs(rBody.velocity.z);
        AddVectorObs(rBody.velocity.y);

    }
    public float speed = 10;
    public override void AgentAction(float[] vectorAction, string textAction)
    {
        // Actions, size = 2
        Vector3 controlSignal = Vector3.zero;
        controlSignal.x = vectorAction[0];
        controlSignal.z = vectorAction[1];
        controlSignal.y = vectorAction[2];
        if (vectorAction[2] != 1)
        {
            rBody.AddForce(controlSignal * speed);

        }
        else
        {
            if (floor)
            {
                rBody.AddForce(controlSignal * (0.5f), ForceMode.Impulse);

            }

        }



        // Rewards
        float distanceToTarget = Vector3.Distance(this.transform.position,
                                                  Target.position);

        // Reached target
        //if (transform.position.x > 5 || transform.position.x < -5 || transform.position.z > 5 || transform.position.z < -5)
        //{
        //    score -= 1;

        //    AddReward(-1.0f);
        //    Debug.Log(score);

        //    Done();
        //}

        if (wall.transform.position.x > 6 || wall.transform.position.x < -6 || wall.transform.position.z > 6 || wall.transform.position.z < -6)
        {
            if (transform.position.x < 5 && transform.position.x > -5 && transform.position.z < 5 && transform.position.z > -5)
            {
                score += 1;

                AddReward(1.0f);
                Debug.Log(score);
            }


        }else if ((transform.position.x > 5 || transform.position.x < -5 || transform.position.z > 5 || transform.position.z < -5))
        {
            //{
            score -= 1;

            AddReward(-1.0f);
            Debug.Log(score);

            Done();
        }

    }

}
